# Visual Discord Bot - Strona Internetowa

Oficjalna strona internetowa dla bota Discord "Visual" - zaawansowany bot z funkcjami weryfikacji, ticketów, wiadomości powitalnych i logów.

## Wdrażanie na Netlify

Aby wdrożyć tę stronę na Netlify, wykonaj następujące kroki:

1. **Utwórz konto na Netlify** (jeśli jeszcze go nie masz)
   - Wejdź na [netlify.com](https://www.netlify.com/) i zarejestruj się

2. **Wdrożenie poprzez Interfejs Netlify**
   - Zaloguj się na swoje konto Netlify
   - Przeciągnij i upuść cały folder projektu do obszaru wdrażania na dashboardzie Netlify
   - LUB kliknij "Import an existing project" i wskaż swoje repozytorium Git

3. **Wdrożenie przez Git**
   - Połącz swoje konto GitHub/GitLab/Bitbucket z Netlify
   - Wybierz to repozytorium
   - Netlify automatycznie wykryje ustawienia z pliku `netlify.toml`
   - Kliknij "Deploy site"

4. **Po wdrożeniu**
   - Netlify przypisze losowy subdomenę (np. random-name-123.netlify.app)
   - Możesz zmienić tę nazwę w ustawieniach strony
   - Możesz również skonfigurować własną domenę

## Lokalne testowanie wdrożenia Netlify

Aby przetestować konfigurację Netlify lokalnie przed wdrożeniem:

1. Zainstaluj Netlify CLI: `npm install netlify-cli -g`
2. Uruchom lokalny serwer Netlify: `netlify dev`

## Struktura projektu

- `/client` - Frontend aplikacji (React, Tailwind CSS)
- `/server` - Backend aplikacji (Express)
- `/netlify/functions` - Funkcje serverless dla Netlify
- `netlify.toml` - Konfiguracja wdrożenia dla Netlify