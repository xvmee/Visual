import { useEffect } from 'react';
import LoadingScreen from '@/components/LoadingScreen';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import BannerSection from '@/components/BannerSection';
import FeaturesSection from '@/components/FeaturesSection';
import StatsSection from '@/components/StatsSection';
import AboutSection from '@/components/AboutSection';
import CTASection from '@/components/CTASection';
import Footer from '@/components/Footer';

const Home = () => {
  // Apply custom styles for scrollbar when component mounts
  useEffect(() => {
    const style = document.createElement('style');
    style.innerHTML = `
      ::-webkit-scrollbar {
        width: 8px;
      }
      
      ::-webkit-scrollbar-track {
        background: #171717;
      }
      
      ::-webkit-scrollbar-thumb {
        background: hsl(338, 100%, 50%);
        border-radius: 4px;
      }
      
      ::-webkit-scrollbar-thumb:hover {
        background: hsl(338, 100%, 60%);
      }
      
      html {
        scroll-behavior: smooth;
      }
      
      body {
        font-family: 'Inter', sans-serif;
      }
      
      h1, h2, h3, h4, h5, h6 {
        font-family: 'Montserrat', sans-serif;
      }
    `;
    document.head.appendChild(style);
    
    return () => {
      document.head.removeChild(style);
    };
  }, []);

  return (
    <div className="bg-black text-white overflow-x-hidden">
      <LoadingScreen />
      <Header />
      <HeroSection />
      <BannerSection />
      <FeaturesSection />
      <StatsSection />
      <AboutSection />
      <CTASection />
      <Footer />
    </div>
  );
};

export default Home;
