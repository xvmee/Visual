import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const BannerSection = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  return (
    <section ref={ref} className="relative py-16 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://i.imgur.com/2jNSHfP.jpg" 
          alt="Visual Banner" 
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/90 to-black/60"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          className="text-center max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold font-montserrat mb-6 text-shadow-[0_0_5px_rgba(255,0,110,0.7)]">
            Transform Your Discord Server
          </h2>
          <p className="text-xl text-gray-300 mb-10">
            Visual brings professional management and engagement tools to make your community thrive.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default BannerSection;
