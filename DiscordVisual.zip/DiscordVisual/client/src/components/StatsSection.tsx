import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

interface StatItemProps {
  value: string;
  label: string;
  delay: number;
}

const StatItem = ({ value, label, delay }: StatItemProps) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [displayValue, setDisplayValue] = useState('0');
  
  useEffect(() => {
    if (inView) {
      // Remove non-numeric characters for animation
      const numericValue = value.replace(/\D/g, '');
      
      // Animate only if it's a number
      if (numericValue && !isNaN(Number(numericValue))) {
        let interval: NodeJS.Timeout;
        const endValue = parseInt(numericValue);
        const duration = 1500; // ms
        const stepTime = 20; // ms
        const totalSteps = duration / stepTime;
        const stepValue = endValue / totalSteps;
        let currentStep = 0;
        
        interval = setInterval(() => {
          currentStep += 1;
          const newValue = Math.min(Math.floor(stepValue * currentStep), endValue);
          setDisplayValue(newValue.toString());
          
          if (currentStep >= totalSteps) {
            clearInterval(interval);
            setDisplayValue(numericValue);
          }
        }, stepTime);
        
        return () => clearInterval(interval);
      } else {
        // If not a number, just set the value directly
        setDisplayValue(value);
      }
    }
  }, [inView, value]);

  return (
    <motion.div 
      ref={ref}
      className="p-6"
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.5, delay }}
    >
      <div className="text-4xl font-bold text-primary mb-2">
        {displayValue}
        {value.includes('+') && '+'}
        {value.includes('%') && '%'}
      </div>
      <div className="text-xl text-gray-300">{label}</div>
    </motion.div>
  );
};

const StatsSection = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  const stats = [
    { value: '500+', label: 'Servers' },
    { value: '100K+', label: 'Users' },
    { value: '99.9%', label: 'Uptime' },
    { value: '50+', label: 'Commands' }
  ];

  return (
    <section id="stats" className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <motion.div 
          ref={ref}
          className="bg-black/60 rounded-2xl p-8 md:p-12 relative overflow-hidden border border-primary/30"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.7 }}
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary opacity-10 rounded-full filter blur-3xl"></div>
          
          <div className="relative z-10">
            <motion.h2 
              className="text-3xl md:text-4xl font-bold font-montserrat mb-12 text-center"
              initial={{ opacity: 0, y: 10 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 10 }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <span className="bg-gradient-to-r from-primary to-primaryLight bg-clip-text text-transparent">
                Visual By The Numbers
              </span>
            </motion.h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
              {stats.map((stat, index) => (
                <StatItem 
                  key={index}
                  value={stat.value}
                  label={stat.label}
                  delay={0.3 + index * 0.1}
                />
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default StatsSection;
