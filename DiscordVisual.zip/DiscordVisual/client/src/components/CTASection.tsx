import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { DiscordIcon } from './ui/icons';
import BackgroundElements from './BackgroundElements';

const CTASection = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section className="py-20 relative overflow-hidden">
      {/* Background with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1603145733146-ae562a55031e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80" 
          alt="Cyber Background" 
          className="w-full h-full object-cover opacity-20"
        />
        <BackgroundElements variant="cta" />
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          ref={ref}
          className="max-w-4xl mx-auto text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.7 }}
        >
          <motion.h2 
            className="text-4xl md:text-5xl font-bold font-montserrat mb-6 leading-tight"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            Ready to Transform Your{' '}
            <span className="bg-gradient-to-r from-primary to-primaryLight bg-clip-text text-transparent">
              Discord Server
            </span>?
          </motion.h2>
          
          <motion.p 
            className="text-xl text-gray-300 mb-10"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.7, delay: 0.3 }}
          >
            Join thousands of server admins who trust Visual to help manage and enhance their Discord communities.
          </motion.p>
          
          <motion.a 
            href="https://discord.com/oauth2/authorize?client_id=1330596128084983889&permissions=8&integration_type=0&scope=bot"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center px-10 py-4 bg-primary hover:bg-primaryLight text-white font-bold rounded-full transition-all duration-300 text-xl shadow-[0_0_10px_rgba(255,0,110,0.7)] hover:shadow-[0_0_20px_rgba(255,0,110,0.9)] mx-auto max-w-max"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.97 }}
          >
            <DiscordIcon className="w-6 h-6 mr-2" />
            Add Visual to Discord
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection;
