import { useState, useEffect } from 'react';
import { motion, useScroll, useMotionValueEvent } from 'framer-motion';
import { Link } from 'wouter';
import { DiscordIcon } from './ui/icons';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    setIsScrolled(latest > 50);
  });

  // Close mobile menu when resizing to desktop
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setIsOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const toggleMenu = () => setIsOpen(!isOpen);

  const scrollToSection = (id: string) => {
    setIsOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <motion.header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled ? 'py-2 backdrop-blur-md bg-black/80 shadow-md' : 'py-3 bg-black/40 backdrop-blur-sm'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <Link href="/">
            <a className="flex items-center">
              <img 
                src="https://i.imgur.com/xSE1E6E.jpg" 
                alt="Visual Bot Logo" 
                className="h-10 w-10 rounded-full mr-3"
              />
              <span className="text-2xl font-bold font-montserrat bg-gradient-to-r from-primary to-primaryLight bg-clip-text text-transparent">
                Visual
              </span>
            </a>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <button 
              onClick={() => scrollToSection('home')}
              className="text-white hover:text-primary transition-colors duration-300"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('features')}
              className="text-white hover:text-primary transition-colors duration-300"
            >
              Features
            </button>
            <button 
              onClick={() => scrollToSection('stats')}
              className="text-white hover:text-primary transition-colors duration-300"
            >
              Stats
            </button>
            <button 
              onClick={() => scrollToSection('about')}
              className="text-white hover:text-primary transition-colors duration-300"
            >
              About
            </button>
          </nav>
          
          {/* Add Button (Desktop) */}
          <a 
            href="https://discord.com/oauth2/authorize?client_id=1330596128084983889&permissions=8&integration_type=0&scope=bot"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:flex items-center px-6 py-2 bg-primary hover:bg-primaryLight text-white font-semibold rounded-full transition-all duration-300 shadow-[0_0_10px_rgba(255,0,110,0.7)] hover:shadow-[0_0_20px_rgba(255,0,110,0.9)]"
          >
            <DiscordIcon className="w-5 h-5 mr-2" />
            Add to Discord
          </a>
          
          {/* Mobile Menu Button */}
          <button 
            onClick={toggleMenu}
            className="md:hidden text-white focus:outline-none"
            aria-label="Toggle mobile menu"
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-6 w-6" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              {isOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
        
        {/* Mobile Navigation */}
        <motion.div 
          className="md:hidden overflow-hidden"
          initial={false}
          animate={{ height: isOpen ? 'auto' : 0, opacity: isOpen ? 1 : 0 }}
          transition={{ duration: 0.3 }}
        >
          {isOpen && (
            <div className="mt-4 pb-4 flex flex-col space-y-4">
              <button 
                onClick={() => scrollToSection('home')}
                className="text-white hover:text-primary transition-colors duration-300"
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection('features')}
                className="text-white hover:text-primary transition-colors duration-300"
              >
                Features
              </button>
              <button 
                onClick={() => scrollToSection('stats')}
                className="text-white hover:text-primary transition-colors duration-300"
              >
                Stats
              </button>
              <button 
                onClick={() => scrollToSection('about')}
                className="text-white hover:text-primary transition-colors duration-300"
              >
                About
              </button>
              <a 
                href="https://discord.com/oauth2/authorize?client_id=1330596128084983889&permissions=8&integration_type=0&scope=bot"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center px-6 py-2 bg-primary hover:bg-primaryLight text-white font-semibold rounded-full transition-all duration-300 shadow-[0_0_10px_rgba(255,0,110,0.7)] hover:shadow-[0_0_20px_rgba(255,0,110,0.9)]"
              >
                <DiscordIcon className="w-5 h-5 mr-2" />
                Add to Discord
              </a>
            </div>
          )}
        </motion.div>
      </div>
    </motion.header>
  );
};

export default Header;
