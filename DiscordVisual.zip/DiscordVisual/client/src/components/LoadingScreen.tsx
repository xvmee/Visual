import { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';

const LoadingScreen = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-50 bg-darkBg flex justify-center items-center"
        >
          <div className="relative w-32 h-32">
            <motion.div 
              className="absolute w-full h-full border-4 border-transparent border-t-primary rounded-full"
              animate={{ rotate: 360 }}
              transition={{ 
                duration: 2,
                ease: "linear",
                repeat: Infinity
              }}
            />
            <motion.div 
              className="absolute w-[80%] h-[80%] top-[10%] left-[10%] border-4 border-transparent border-t-primaryLight rounded-full"
              animate={{ rotate: 360 }}
              transition={{ 
                duration: 1.5,
                ease: "linear",
                repeat: Infinity,
                repeatType: "reverse"
              }}
            />
            <motion.div 
              className="absolute w-[60%] h-[60%] top-[20%] left-[20%] flex justify-center items-center"
              animate={{ 
                scale: [0.9, 1.1, 0.9]
              }}
              transition={{ 
                duration: 1.5,
                ease: "easeInOut",
                repeat: Infinity
              }}
            >
              <img 
                src="https://i.imgur.com/xSE1E6E.jpg" 
                alt="Visual Bot Logo" 
                className="w-full h-auto rounded-full"
              />
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default LoadingScreen;
