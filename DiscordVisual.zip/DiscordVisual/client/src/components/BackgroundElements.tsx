import { motion } from 'framer-motion';

interface BackgroundElementsProps {
  variant?: 'hero' | 'features' | 'cta';
}

const BackgroundElements = ({ variant = 'hero' }: BackgroundElementsProps) => {
  if (variant === 'hero') {
    return (
      <div className="absolute inset-0 overflow-hidden z-0">
        <motion.div 
          className="absolute top-20 left-10 w-32 h-32 bg-primary opacity-10 rounded-full filter blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.15, 0.1],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div 
          className="absolute top-40 right-20 w-40 h-40 bg-primary/30 opacity-10 rounded-full filter blur-3xl"
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.1, 0.15, 0.1],
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1
          }}
        />
        <motion.div 
          className="absolute bottom-20 left-1/3 w-36 h-36 bg-primary/60 opacity-10 rounded-full filter blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.15, 0.1],
          }}
          transition={{
            duration: 4.5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.5
          }}
        />
      </div>
    );
  }
  
  if (variant === 'features') {
    return (
      <div className="absolute inset-0 overflow-hidden z-0">
        <motion.div 
          className="absolute w-full h-full"
          style={{
            background: "radial-gradient(circle at 50% 50%, rgba(255, 0, 110, 0.05) 0%, transparent 70%)"
          }}
        />
        <motion.div 
          className="absolute -top-1/4 left-1/4 w-96 h-96 bg-primary opacity-[0.03] rounded-full"
          animate={{ rotate: 360 }}
          transition={{ 
            duration: 30, 
            repeat: Infinity, 
            ease: "linear" 
          }}
        />
      </div>
    );
  }
  
  if (variant === 'cta') {
    return (
      <div className="absolute inset-0 overflow-hidden z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black/90" />
        
        <motion.div 
          className="absolute -top-32 -right-32 w-64 h-64 bg-primary opacity-5 rounded-full"
          animate={{ 
            y: [0, 20, 0],
            scale: [1, 1.1, 1]
          }}
          transition={{ 
            duration: 8, 
            repeat: Infinity, 
            ease: "easeInOut" 
          }}
        />
        
        <motion.div 
          className="absolute bottom-0 left-0 w-full h-1/3"
          style={{
            background: "linear-gradient(to top, rgba(255, 0, 110, 0.05), transparent)"
          }}
        />
      </div>
    );
  }
  
  return null;
};

export default BackgroundElements;
