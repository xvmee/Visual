import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { 
  VerificationIcon, 
  TicketIcon, 
  WelcomeIcon, 
  LoggingIcon, 
  ModerationIcon, 
  CommandsIcon,
  DiscordIcon
} from './ui/icons';
import BackgroundElements from './BackgroundElements';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  index: number;
}

const FeatureCard = ({ icon, title, description, index }: FeatureCardProps) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <motion.div 
      ref={ref}
      className="bg-black/60 rounded-xl p-6 border border-primary/20 hover:border-primary/50 transition-all duration-300 shadow-lg hover:shadow-primary/20 hover:-translate-y-1"
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
        {icon}
      </div>
      <h3 className="text-xl font-semibold font-montserrat mb-3">{title}</h3>
      <p className="text-gray-400">
        {description}
      </p>
    </motion.div>
  );
};

const FeaturesSection = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const features = [
    {
      icon: <VerificationIcon className="text-primary text-2xl w-7 h-7" />,
      title: "Verification System",
      description: "Protect your server from spam and bots with an advanced verification system including captcha, email, and role-based verification."
    },
    {
      icon: <TicketIcon className="text-primary text-2xl w-7 h-7" />,
      title: "Ticket System",
      description: "Streamline support with a custom ticket system. Handle user inquiries efficiently with categorized tickets and saved transcripts."
    },
    {
      icon: <WelcomeIcon className="text-primary text-2xl w-7 h-7" />,
      title: "Welcome System",
      description: "Make new members feel at home with customizable welcome messages, DMs, and special role assignments for newcomers."
    },
    {
      icon: <LoggingIcon className="text-primary text-2xl w-7 h-7" />,
      title: "Advanced Logging",
      description: "Keep track of everything happening in your server with detailed logs for moderation actions, message edits, voice activity, and more."
    },
    {
      icon: <ModerationIcon className="text-primary text-2xl w-7 h-7" />,
      title: "Moderation Tools",
      description: "Keep your community safe with powerful moderation commands, auto-mod features, word filters, and anti-raid protection."
    },
    {
      icon: <CommandsIcon className="text-primary text-2xl w-7 h-7" />,
      title: "Custom Commands",
      description: "Create personalized commands tailored to your server's needs with an intuitive command creation system."
    }
  ];

  return (
    <section id="features" className="relative py-20 bg-black/40">
      <BackgroundElements variant="features" />
      
      <div className="container mx-auto px-4">
        <motion.div 
          ref={ref}
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold font-montserrat mb-4">
            <span className="bg-gradient-to-r from-primary to-primaryLight bg-clip-text text-transparent">
              Powerful Features
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Visual comes packed with everything you need to run a successful Discord server
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard 
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              index={index}
            />
          ))}
        </div>
        
        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <motion.a 
            href="https://discord.com/oauth2/authorize?client_id=1330596128084983889&permissions=8&integration_type=0&scope=bot"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center px-8 py-3 bg-primary hover:bg-primaryLight text-white font-semibold rounded-full transition-all duration-300 text-lg shadow-[0_0_10px_rgba(255,0,110,0.7)] hover:shadow-[0_0_20px_rgba(255,0,110,0.9)] mx-auto"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          >
            <DiscordIcon className="w-5 h-5 mr-2" />
            Add Visual to Your Server
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
};

export default FeaturesSection;
