import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { CheckIcon } from './ui/icons';

interface BenefitProps {
  text: string;
  delay: number;
}

const Benefit = ({ text, delay }: BenefitProps) => {
  return (
    <motion.div 
      className="flex items-center mt-3"
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <div className="flex-shrink-0">
        <CheckIcon className="w-6 h-6 text-primary" />
      </div>
      <div className="ml-4">
        <p className="text-gray-300">{text}</p>
      </div>
    </motion.div>
  );
};

const AboutSection = () => {
  const [sectionRef, sectionInView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [leftColRef, leftColInView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [rightColRef, rightColInView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [btnRef, btnInView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section id="about" className="py-20 bg-black/40 relative overflow-hidden">
      {/* Background Animation */}
      <div className="absolute inset-0 z-0">
        <motion.div 
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary opacity-5 rounded-full"
          animate={{ rotate: 360 }}
          transition={{ 
            duration: 30, 
            repeat: Infinity, 
            ease: "linear" 
          }}
        />
        <motion.div 
          className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-primaryLight opacity-5 rounded-full"
          animate={{ rotate: -360 }}
          transition={{ 
            duration: 25, 
            repeat: Infinity, 
            ease: "linear" 
          }}
        />
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          ref={sectionRef}
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={sectionInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold font-montserrat mb-4">
            <span className="bg-gradient-to-r from-primary to-primaryLight bg-clip-text text-transparent">
              Why Choose Visual
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            A modern Discord bot designed with your server's needs in mind
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          <motion.div 
            ref={leftColRef}
            className="bg-black/60 p-8 rounded-xl border border-primary/20"
            initial={{ opacity: 0, x: -20 }}
            animate={leftColInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="text-2xl font-semibold font-montserrat mb-4">Designed For Ease of Use</h3>
            <p className="text-gray-300 mb-6">
              Visual was built from the ground up to be intuitive and user-friendly. No complicated setup or technical knowledge required.
              All features can be configured through simple commands or an interactive dashboard.
            </p>
            
            <Benefit 
              text="Simple setup process that takes minutes, not hours" 
              delay={0.1}
            />
            <Benefit 
              text="Intuitive command structure with helpful documentation" 
              delay={0.2}
            />
            <Benefit 
              text="Regular updates with new features and improvements" 
              delay={0.3}
            />
          </motion.div>
          
          <motion.div 
            ref={rightColRef}
            className="bg-black/60 p-8 rounded-xl border border-primary/20"
            initial={{ opacity: 0, x: 20 }}
            animate={rightColInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="text-2xl font-semibold font-montserrat mb-4">Reliable & Secure</h3>
            <p className="text-gray-300 mb-6">
              We understand that reliability is crucial for your Discord server. Visual is hosted on high-performance 
              servers with 99.9% uptime and built with security best practices to keep your data safe.
            </p>
            
            <Benefit 
              text="Continuous monitoring and automatic recovery systems" 
              delay={0.1}
            />
            <Benefit 
              text="Enterprise-grade security to protect your server data" 
              delay={0.2}
            />
            <Benefit 
              text="Dedicated support team ready to help when needed" 
              delay={0.3}
            />
          </motion.div>
        </div>
        
        <motion.div 
          ref={btnRef}
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={btnInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          <motion.a 
            href="https://discord.com/oauth2/authorize?client_id=1330596128084983889&permissions=8&integration_type=0&scope=bot"
            target="_blank"
            rel="noopener noreferrer"
            className="px-8 py-3 bg-primary hover:bg-primaryLight text-white font-semibold rounded-full transition-all duration-300 text-lg inline-block shadow-[0_0_10px_rgba(255,0,110,0.7)] hover:shadow-[0_0_20px_rgba(255,0,110,0.9)]"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          >
            Get Started With Visual
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutSection;
