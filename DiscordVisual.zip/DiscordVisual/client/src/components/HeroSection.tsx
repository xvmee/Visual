import { motion } from 'framer-motion';
import { DiscordIcon, ChevronDownIcon } from './ui/icons';
import BackgroundElements from './BackgroundElements';

const HeroSection = () => {
  const scrollToFeatures = () => {
    const featuresSection = document.getElementById('features');
    if (featuresSection) {
      const headerOffset = 80;
      const elementPosition = featuresSection.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="relative min-h-screen pt-24 flex items-center">
      <BackgroundElements variant="hero" />
      
      <div className="container mx-auto px-4 z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-10">
          <motion.div 
            className="md:w-1/2 text-center md:text-left"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold font-montserrat mb-4 leading-tight">
              <span className="bg-gradient-to-r from-primary to-primaryLight bg-clip-text text-transparent text-shadow-[0_0_5px_rgba(255,0,110,0.7)]">
                Visual
              </span> 
              <span className="block">The Ultimate Discord Bot</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-lg mx-auto md:mx-0">
              Enhance your Discord server with powerful moderation, verification, ticket systems, logs, welcome messages and much more.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <motion.a 
                href="https://discord.com/oauth2/authorize?client_id=1330596128084983889&permissions=8&integration_type=0&scope=bot"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center px-8 py-3 bg-primary hover:bg-primaryLight text-white font-semibold rounded-full transition-all duration-300 text-lg shadow-[0_0_10px_rgba(255,0,110,0.7)] hover:shadow-[0_0_20px_rgba(255,0,110,0.9)]"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
              >
                <DiscordIcon className="w-5 h-5 mr-2" />
                Add to Discord
              </motion.a>
              <motion.button
                onClick={scrollToFeatures}
                className="flex items-center justify-center px-8 py-3 bg-black/40 hover:bg-black/60 text-white font-semibold rounded-full transition-all duration-300 text-lg border border-primary/30 hover:border-primary"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.98 }}
              >
                Explore Features
              </motion.button>
            </div>
          </motion.div>
          
          <motion.div 
            className="md:w-1/2 flex justify-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.5 }}
          >
            <motion.div 
              className="relative w-full max-w-md"
              animate={{ y: [0, -10, 0] }}
              transition={{ 
                duration: 3, 
                repeat: Infinity, 
                ease: "easeInOut" 
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-primary to-primaryLight opacity-20 blur-xl rounded-3xl"></div>
              <img 
                src="https://i.imgur.com/xSE1E6E.jpg" 
                alt="Visual Bot" 
                className="relative z-10 rounded-2xl w-full shadow-2xl"
              />
              <div className="absolute -bottom-5 -right-5 w-28 h-28 bg-primary/20 rounded-full filter blur-xl"></div>
            </motion.div>
          </motion.div>
        </div>
      </div>
      
      <motion.div 
        className="absolute bottom-10 left-0 right-0 flex justify-center"
        animate={{ y: [0, 10, 0] }}
        transition={{ 
          duration: 1.5, 
          repeat: Infinity, 
          ease: "easeInOut" 
        }}
      >
        <button 
          onClick={scrollToFeatures} 
          className="text-primary"
          aria-label="Scroll to features"
        >
          <ChevronDownIcon className="w-8 h-8" />
        </button>
      </motion.div>
    </section>
  );
};

export default HeroSection;
