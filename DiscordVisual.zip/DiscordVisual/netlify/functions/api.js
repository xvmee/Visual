// Prosta funkcja serverless dla Netlify

export async function handler(event, context) {
  // Możesz tutaj obsłużyć różne ścieżki API, jeśli potrzebujesz
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: "API Visual Bot działa na Netlify!",
      timestamp: new Date().toISOString()
    }),
    headers: {
      "Content-Type": "application/json"
    }
  };
}