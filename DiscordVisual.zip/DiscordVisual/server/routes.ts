import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve favicon if requested
  app.get('/favicon.ico', (req, res) => {
    res.redirect('https://i.imgur.com/xSE1E6E.jpg');
  });

  // You can add additional API routes here if needed for the landing page
  // Currently this is a static site without backend functionality

  const httpServer = createServer(app);

  return httpServer;
}
